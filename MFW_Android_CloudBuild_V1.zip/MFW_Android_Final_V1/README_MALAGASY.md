# Malagasy Football Worldwide — Android V1 🇲🇬⚽

Vrai projet Android basé sur le prototype MFW.

## Construire l'APK
1. Installer Android Studio sur un PC.
2. Ouvrir ce dossier.
3. Attendre Gradle Sync.
4. Build > Build APK(s).
5. APK: `app/build/outputs/apk/debug/app-debug.apk`

`BUILD_APK_WINDOWS.bat` est inclus pour simplifier le lancement du build sous Windows.

Package: `com.malagasyfootballworldwide.app`
Version: 1.0
