@echo off
cd /d "%~dp0"
where gradle >nul 2>nul
if %errorlevel%==0 (gradle :app:assembleDebug) else (echo Ouvrez ce projet dans Android Studio puis Build ^> Build APK(s).)
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
