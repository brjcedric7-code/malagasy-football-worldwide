# MFW — Build APK amin'ny téléphone ihany

1. Mamoròna compte GitHub.
2. Mamoròna repository vaovao (oh: malagasy-football-worldwide-app).
3. Ampidiro ao amin'ilay repository ny fichiers rehetra ato amin'ity projet ity.
4. Rehefa tafiditra ny dossier `.github/workflows/build-apk.yml`, sokafy ny onglet **Actions**.
5. Safidio **Build MFW APK** ary tsindrio **Run workflow**.
6. Rehefa vita ny build, sokafy ilay run ary alao ao amin'ny **Artifacts** ny `MFW-Android-V1-debug`.
7. Ao anatiny no misy `app-debug.apk`.

Fanamarihana: GitHub Actions dia afaka manao build sy mitahiry artifact azo alaina rehefa vita ny workflow. Ny APK debug dia natao ho an'ny test aloha; rehefa vonona ny app dia hanao release signing manokana isika.
